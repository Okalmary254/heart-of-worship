create table if not exists registrations (
  id bigserial primary key,
  ticket_id text unique not null,
  name text not null,
  event_name text,
  location text,
  event_time text,
  created_at timestamptz default now(),
  checked_in_at timestamptz
);
